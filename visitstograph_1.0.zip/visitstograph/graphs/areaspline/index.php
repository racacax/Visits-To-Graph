<?php 
include('../../config.php');
if(isset($_GET['m']) && ($_GET['m'] == '01')) { $month = "janvier"; } if(isset($_GET['m']) && ($_GET['m'] == '02')) { $month = "février"; } if(isset($_GET['m']) && ($_GET['m'] == '03')) { $month = "mars"; } if(isset($_GET['m']) && ($_GET['m'] == '04')) { $month = "avril"; } if(isset($_GET['m']) && ($_GET['m'] == '05')) { $month = "mai"; } if(isset($_GET['m']) && ($_GET['m'] == '06')) { $month = "juin"; } if(isset($_GET['m']) && ($_GET['m'] == '07')) { $month = "juillet"; } if(isset($_GET['m']) && ($_GET['m'] == '08')) { $month = "août"; } if(isset($_GET['m']) && ($_GET['m'] == '09')) { $month = "septembre"; } if(isset($_GET['m']) && ($_GET['m'] == '10')) { $month = "octobre"; } if(isset($_GET['m']) && ($_GET['m'] == '11')) { $month = "novembre"; } if(isset($_GET['m']) && ($_GET['m'] == '12')) { $month = "décembre"; }
if(isset($_GET['mode']) && ($_GET['mode'] == 'day')) { $date1 = 'par jour en '.$month.' '.$_GET['y']; } else if(isset($_GET['mode']) && ($_GET['mode'] == 'month')) { $date1 = 'par mois de l\\\'année '.$_GET['y']; } else if(isset($_GET['mode']) && ($_GET['mode'] == 'year')) { $date1 = " de l\'année ".$_GET['y']; } 
?>
<!DOCTYPE html>
<html><head>
		<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
		<title>Visiteurs de <?php echo $nomdusite.' '.$date1; ?></title>

		<script type="text/javascript" src="index_fichiers/jquery.js"></script>
		<style type="text/css">
${demo.css}
		</style>
		<script type="text/javascript">
$(function () {
    $('#container').highcharts({
        chart: {
            type: 'areaspline'
        },
        title: {
            text: 'Visiteurs de <?php echo $nomdusite.' '.$date1; ?>'
        },
        legend: {
            layout: 'vertical',
            align: 'left',
            verticalAlign: 'top',
            x: 150,
            y: 100,
            floating: true,
            borderWidth: 1,
            backgroundColor: (Highcharts.theme && Highcharts.theme.legendBackgroundColor) || '#FFFFFF'
        },
        xAxis: {
			<?php if(isset($_GET['mode']) && ($_GET['mode'] == "day")) { ?>
            categories: [
                <?php $annee=filter_var($_GET['y'], FILTER_SANITIZE_NUMBER_INT);
$mois=filter_var($_GET['m'], FILTER_SANITIZE_NUMBER_INT);
for ($jour=1; $jour <= cal_days_in_month(CAL_GREGORIAN, (int) $mois, $annee); $jour++) {



  // 5) On affiche la ligne pour le jour concerné
			print "'".$jour."/".$mois."/".$annee."',\r\n"; } ?>
             
            ],
			<?php } ?>
					<?php if(isset($_GET['mode']) && ($_GET['mode'] == "month")) { ?>
            categories: [
                '01/<?php echo $_GET['y']; ?>',
				'02/<?php echo $_GET['y']; ?>',
				'03/<?php echo $_GET['y']; ?>',
				'04/<?php echo $_GET['y']; ?>',
				'05/<?php echo $_GET['y']; ?>',
				'06/<?php echo $_GET['y']; ?>',
				'07/<?php echo $_GET['y']; ?>',
				'08/<?php echo $_GET['y']; ?>',
				'09/<?php echo $_GET['y']; ?>',
				'10/<?php echo $_GET['y']; ?>',
				'11/<?php echo $_GET['y']; ?>',
				'12/<?php echo $_GET['y']; ?>'
             
            ],
			<?php } ?>
           
        },
        yAxis: {
            title: {
                text: 'Visiteurs'
            }
        },
        tooltip: {
            shared: true,
            valueSuffix: ' visiteurs'
        },
        credits: {
            enabled: false
        },
        plotOptions: {
            areaspline: {
                fillOpacity: 0.5
            }
        },
		<?php if(isset($_GET['mode']) && ($_GET['mode'] == "day")) { ?>
        series: [{
            name: 'Visiteurs',
            data: [<?php $annee=filter_var($_GET['y'], FILTER_SANITIZE_NUMBER_INT);
$mois=filter_var($_GET['m'], FILTER_SANITIZE_NUMBER_INT);
for ($jour=1; $jour <= cal_days_in_month(CAL_GREGORIAN, (int) $mois, $annee); $jour++) {
if($jour<10) { $jour = '0'.$jour; }
  // 3) On récupère le nombre de visites ce jour
  $nb_visites = @file_get_contents($urlcompteur.$jour.'-'.$mois.'-'.$annee);
  // 4) si on n'obtient rien, c'est probablement que le fichier n'existe pas et on le met donc à 0
  if (empty($nb_visites)) $nb_visites = 0;

  // 5) On affiche la ligne pour le jour concerné
			print $nb_visites.",\r\n"; } ?>]
        },]
		<?php } ?>
				<?php if(isset($_GET['mode']) && ($_GET['mode'] == "month")) { ?>
        series: [{
            name: 'Visiteurs',
            data: [<?php echo '0'. @file_get_contents($urlcompteur.'01-'.$_GET['y']); ?>,<?php echo '0'. @file_get_contents($urlcompteur.'02-'.$_GET['y']); ?>,<?php echo '0'. @file_get_contents($urlcompteur.'03-'.$_GET['y']); ?>,<?php echo '0'. @file_get_contents($urlcompteur.'04-'.$_GET['y']); ?>,<?php echo '0'. @file_get_contents($urlcompteur.'05-'.$_GET['y']); ?>,<?php echo '0'. @file_get_contents($urlcompteur.'06-'.$_GET['y']); ?>,<?php echo '0'. @file_get_contents($urlcompteur.'07-'.$_GET['y']); ?>,<?php echo '0'. @file_get_contents($urlcompteur.'08-'.$_GET['y']); ?>,<?php echo '0'. @file_get_contents($urlcompteur.'09-'.$_GET['y']); ?>,<?php echo '0'. @file_get_contents($urlcompteur.'10-'.$_GET['y']); ?>,<?php echo '0'. @file_get_contents($urlcompteur.'11-'.$_GET['y']); ?>,<?php echo '0'. @file_get_contents($urlcompteur.'12-'.$_GET['y']); ?>]
        },]
		<?php } ?>
    });
});
		</script>
	</head>
	<body>
<script src="index_fichiers/highcharts.js"></script>
<script src="index_fichiers/exporting.js"></script>

<div data-highcharts-chart="0" id="container" style="min-width: 310px; height: 400px; margin: 0 auto"><div style="position: relative; overflow: hidden; width: 1584px; height: 400px; text-align: left; line-height: normal; z-index: 0; left: 0px; top: 0px;" id="highcharts-0" class="highcharts-container"><svg height="400" width="1584" xmlns="http://www.w3.org/2000/svg" style="font-family:&quot;Lucida Grande&quot;, &quot;Lucida Sans Unicode&quot;, Arial, Helvetica, sans-serif;font-size:12px;" version="1.1"><desc>Created with Highcharts 4.2.3</desc><defs><clipPath id="highcharts-1"><rect height="306" width="1495" y="0" x="0"></rect></clipPath></defs><rect class=" highcharts-background" fill="#FFFFFF" height="400" width="1584" y="0" x="0"></rect><path zIndex="0" d="M 1146.5 53 L 1146.5 359 1573.5 359 1573.5 53" fill="rgba(68, 170, 213, .2)"></path><g zIndex="1" class="highcharts-grid"></g><g zIndex="1" class="highcharts-grid"><path opacity="1" zIndex="1" stroke-width="1" stroke="#D8D8D8" d="M 79 359.5 L 1574 359.5" fill="none"></path><path opacity="1" zIndex="1" stroke-width="1" stroke="#D8D8D8" d="M 79 308.5 L 1574 308.5" fill="none"></path><path opacity="1" zIndex="1" stroke-width="1" stroke="#D8D8D8" d="M 79 257.5 L 1574 257.5" fill="none"></path><path opacity="1" zIndex="1" stroke-width="1" stroke="#D8D8D8" d="M 79 206.5 L 1574 206.5" fill="none"></path><path opacity="1" zIndex="1" stroke-width="1" stroke="#D8D8D8" d="M 79 155.5 L 1574 155.5" fill="none"></path><path opacity="1" zIndex="1" stroke-width="1" stroke="#D8D8D8" d="M 79 104.5 L 1574 104.5" fill="none"></path><path opacity="1" zIndex="1" stroke-width="1" stroke="#D8D8D8" d="M 79 52.5 L 1574 52.5" fill="none"></path></g><g zIndex="2" class="highcharts-axis"><path opacity="1" stroke-width="1" stroke="#C0D0E0" d="M 292.5 359 L 292.5 369" fill="none"></path><path opacity="1" stroke-width="1" stroke="#C0D0E0" d="M 505.5 359 L 505.5 369" fill="none"></path><path opacity="1" stroke-width="1" stroke="#C0D0E0" d="M 719.5 359 L 719.5 369" fill="none"></path><path opacity="1" stroke-width="1" stroke="#C0D0E0" d="M 932.5 359 L 932.5 369" fill="none"></path><path opacity="1" stroke-width="1" stroke="#C0D0E0" d="M 1146.5 359 L 1146.5 369" fill="none"></path><path opacity="1" stroke-width="1" stroke="#C0D0E0" d="M 1359.5 359 L 1359.5 369" fill="none"></path><path opacity="1" stroke-width="1" stroke="#C0D0E0" d="M 1574.5 359 L 1574.5 369" fill="none"></path><path opacity="1" stroke-width="1" stroke="#C0D0E0" d="M 78.5 359 L 78.5 369" fill="none"></path><path zIndex="7" stroke-width="1" stroke="#C0D0E0" d="M 79 359.5 L 1574 359.5" fill="none"></path></g><g zIndex="2" class="highcharts-axis"><text y="206" style="color:#707070;fill:#707070;" class=" highcharts-yaxis-title" transform="translate(0,0) rotate(270 29.66666603088379 206)" text-anchor="middle" zIndex="7" x="29.66666603088379"><tspan>Fruit units</tspan></text></g><g zIndex="3" class="highcharts-series-group"><path d="M 1040 267.4 C 1053.32 267.4 1053.32 287.4 1040 287.4 C 1026.68 287.4 1026.68 267.4 1040 267.4 Z" zIndex="-1" fill-opacity="0.25" fill="#7cb5ec"></path><path d="M 1040 287.8 C 1053.32 287.8 1053.32 307.8 1040 307.8 C 1026.68 307.8 1026.68 287.8 1040 287.8 Z" zIndex="-1" fill-opacity="0.25" fill="#434348"></path><g clip-path="url(#highcharts-1)" transform="translate(79,53) scale(1 1)" zIndex="0.1" class="highcharts-series highcharts-series-0"><path fill-opacity="0.5" zIndex="0" d="M 106.78571428571429 244.8 C 106.78571428571429 244.8 234.92857142857147 224.4 320.3571428571429 224.4 C 405.78571428571433 224.4 448.5 244.8 533.9285714285714 244.8 C 619.3571428571429 244.8 662.0714285714287 204 747.5000000000001 204 C 832.9285714285716 204 875.6428571428572 224.4 961.0714285714287 224.4 C 1046.5 224.4 1089.2142857142858 134.63999999999993 1174.642857142857 102 C 1260.0714285714287 69.35999999999997 1388.2142857142858 61.20000000000002 1388.2142857142858 61.20000000000002 L 1388.2142857142858 306 C 1388.2142857142858 306 1260.0714285714287 306 1174.642857142857 306 C 1089.2142857142858 306 1046.5 306 961.0714285714287 306 C 875.6428571428572 306 832.9285714285716 306 747.5000000000001 306 C 662.0714285714287 306 619.3571428571429 306 533.9285714285714 306 C 448.5 306 405.78571428571433 306 320.3571428571429 306 C 234.92857142857147 306 106.78571428571429 306 106.78571428571429 306" fill="#7cb5ec"></path><path stroke-linecap="round" stroke-linejoin="round" zIndex="1" stroke-width="2" stroke="#7cb5ec" d="M 106.78571428571429 244.8 C 106.78571428571429 244.8 234.92857142857147 224.4 320.3571428571429 224.4 C 405.78571428571433 224.4 448.5 244.8 533.9285714285714 244.8 C 619.3571428571429 244.8 662.0714285714287 204 747.5000000000001 204 C 832.9285714285716 204 875.6428571428572 224.4 961.0714285714287 224.4 C 1046.5 224.4 1089.2142857142858 134.63999999999993 1174.642857142857 102 C 1260.0714285714287 69.35999999999997 1388.2142857142858 61.20000000000002 1388.2142857142858 61.20000000000002" fill="none"></path><path style="" class=" highcharts-tracker" zIndex="2" stroke-width="22" stroke="rgba(192,192,192,0.0001)" visibility="visible" stroke-linejoin="round" d="M 96.78571428571429 244.8 L 106.78571428571429 244.8 C 106.78571428571429 244.8 234.92857142857147 224.4 320.3571428571429 224.4 C 405.78571428571433 224.4 448.5 244.8 533.9285714285714 244.8 C 619.3571428571429 244.8 662.0714285714287 204 747.5000000000001 204 C 832.9285714285716 204 875.6428571428572 224.4 961.0714285714287 224.4 C 1046.5 224.4 1089.2142857142858 134.63999999999993 1174.642857142857 102 C 1260.0714285714287 69.35999999999997 1388.2142857142858 61.20000000000002 1388.2142857142858 61.20000000000002 L 1398.2142857142858 61.20000000000002" fill="none"></path></g><g style="" clip-path="url(#highcharts-2)" transform="translate(79,53) scale(1 1)" zIndex="0.1" class="highcharts-markers highcharts-series-0 highcharts-tracker"><path stroke-width="1" d="M 1388 57.20000000000002 C 1393.328 57.20000000000002 1393.328 65.20000000000002 1388 65.20000000000002 C 1382.672 65.20000000000002 1382.672 57.20000000000002 1388 57.20000000000002 Z" fill="#7cb5ec"></path><path stroke-width="1" d="M 1174 98 C 1179.328 98 1179.328 106 1174 106 C 1168.672 106 1168.672 98 1174 98 Z" fill="#7cb5ec"></path><path stroke="#FFFFFF" stroke-width="1" d="M 961 218.4 C 968.992 218.4 968.992 230.4 961 230.4 C 953.008 230.4 953.008 218.4 961 218.4 Z" fill="#7cb5ec"></path><path stroke-width="1" d="M 747 200 C 752.328 200 752.328 208 747 208 C 741.672 208 741.672 200 747 200 Z" fill="#7cb5ec"></path><path stroke-width="1" d="M 533 240.8 C 538.328 240.8 538.328 248.8 533 248.8 C 527.672 248.8 527.672 240.8 533 240.8 Z" fill="#7cb5ec"></path><path d="M 320 220.4 C 325.328 220.4 325.328 228.4 320 228.4 C 314.672 228.4 314.672 220.4 320 220.4 Z" fill="#7cb5ec"></path><path d="M 106 240.8 C 111.328 240.8 111.328 248.8 106 248.8 C 100.672 248.8 100.672 240.8 106 240.8 Z" fill="#7cb5ec"></path></g><g clip-path="url(#highcharts-1)" transform="translate(79,53) scale(1 1)" zIndex="0.1" class="highcharts-series highcharts-series-1"><path fill-opacity="0.5" zIndex="0" d="M 106.78571428571429 285.6 C 106.78571428571429 285.6 234.92857142857147 257.03999999999996 320.3571428571429 244.8 C 405.78571428571433 232.56 448.5 224.4 533.9285714285714 224.4 C 619.3571428571429 224.4 662.0714285714287 244.8 747.5000000000001 244.8 C 832.9285714285716 244.8 875.6428571428572 244.8 961.0714285714287 244.8 C 1046.5 244.8 1089.2142857142858 204 1174.642857142857 204 C 1260.0714285714287 204 1388.2142857142858 224.4 1388.2142857142858 224.4 L 1388.2142857142858 306 C 1388.2142857142858 306 1260.0714285714287 306 1174.642857142857 306 C 1089.2142857142858 306 1046.5 306 961.0714285714287 306 C 875.6428571428572 306 832.9285714285716 306 747.5000000000001 306 C 662.0714285714287 306 619.3571428571429 306 533.9285714285714 306 C 448.5 306 405.78571428571433 306 320.3571428571429 306 C 234.92857142857147 306 106.78571428571429 306 106.78571428571429 306" fill="#434348"></path><path stroke-linecap="round" stroke-linejoin="round" zIndex="1" stroke-width="3" stroke="#434348" d="M 106.78571428571429 285.6 C 106.78571428571429 285.6 234.92857142857147 257.03999999999996 320.3571428571429 244.8 C 405.78571428571433 232.56 448.5 224.4 533.9285714285714 224.4 C 619.3571428571429 224.4 662.0714285714287 244.8 747.5000000000001 244.8 C 832.9285714285716 244.8 875.6428571428572 244.8 961.0714285714287 244.8 C 1046.5 244.8 1089.2142857142858 204 1174.642857142857 204 C 1260.0714285714287 204 1388.2142857142858 224.4 1388.2142857142858 224.4" fill="none"></path><path style="" class=" highcharts-tracker" zIndex="2" stroke-width="22" stroke="rgba(192,192,192,0.0001)" visibility="visible" stroke-linejoin="round" d="M 96.78571428571429 285.6 L 106.78571428571429 285.6 C 106.78571428571429 285.6 234.92857142857147 257.03999999999996 320.3571428571429 244.8 C 405.78571428571433 232.56 448.5 224.4 533.9285714285714 224.4 C 619.3571428571429 224.4 662.0714285714287 244.8 747.5000000000001 244.8 C 832.9285714285716 244.8 875.6428571428572 244.8 961.0714285714287 244.8 C 1046.5 244.8 1089.2142857142858 204 1174.642857142857 204 C 1260.0714285714287 204 1388.2142857142858 224.4 1388.2142857142858 224.4 L 1398.2142857142858 224.4" fill="none"></path></g><g style="" clip-path="url(#highcharts-2)" transform="translate(79,53) scale(1 1)" zIndex="0.1" class="highcharts-markers highcharts-series-1 highcharts-tracker"><path stroke-width="1" d="M 1388 220.4 L 1392 224.4 1388 228.4 1384 224.4 Z" fill="#434348"></path><path stroke-width="1" d="M 1174 200 L 1178 204 1174 208 1170 204 Z" fill="#434348"></path><path stroke="#FFFFFF" stroke-width="1" d="M 961 238.8 L 967 244.8 961 250.8 955 244.8 Z" fill="#434348"></path><path stroke-width="1" d="M 747 240.8 L 751 244.8 747 248.8 743 244.8 Z" fill="#434348"></path><path stroke-width="1" d="M 533 220.4 L 537 224.4 533 228.4 529 224.4 Z" fill="#434348"></path><path d="M 320 240.8 L 324 244.8 320 248.8 316 244.8 Z" fill="#434348"></path><path d="M 106 281.6 L 110 285.6 106 289.6 102 285.6 Z" fill="#434348"></path></g></g><g transform="translate(1550,10)" zIndex="3" stroke-linecap="round" style="cursor:default;" class="highcharts-button"><title>Chart context menu</title><rect ry="2" rx="2" stroke-width="1" stroke="none" fill="white" height="22" width="24" y="0.5" x="0.5"></rect><path zIndex="1" stroke-width="3" stroke="#666" d="M 6 6.5 L 20 6.5 M 6 11.5 L 20 11.5 M 6 16.5 L 20 16.5" fill="#E0E0E0"></path><text y="12" style="color:black;fill:black;" zIndex="1" x="0"></text></g><text y="24" style="color:#333333;font-size:18px;fill:#333333;width:1520px;" zIndex="4" class="highcharts-title" text-anchor="middle" x="792"><tspan>Average fruit consumption during one week</tspan></text><g transform="translate(160,110)" zIndex="7" class="highcharts-legend"><rect visibility="visible" fill="#FFFFFF" stroke-width="1" stroke="#909090" height="50" width="62" y="0.5" x="0.5"></rect><g zIndex="1"><g><g transform="translate(8,3)" zIndex="1" class="highcharts-legend-item"><text y="15" zIndex="2" text-anchor="start" style="color:#333333;font-size:12px;font-weight:bold;cursor:pointer;fill:#333333;" x="21">John</text><rect fill="#7cb5ec" zIndex="3" height="12" width="16" y="4" x="0"></rect></g><g transform="translate(8,23)" zIndex="1" class="highcharts-legend-item"><text zIndex="2" text-anchor="start" style="color:#333333;font-size:12px;font-weight:bold;cursor:pointer;fill:#333333;" y="15" x="21">Jane</text><rect fill="#434348" zIndex="3" height="12" width="16" y="4" x="0"></rect></g></g></g></g><g zIndex="7" class="highcharts-axis-labels highcharts-xaxis-labels"><text opacity="1" y="378" transform="translate(0,0)" text-anchor="middle" style="color:#606060;cursor:default;font-size:11px;fill:#606060;width:213px;text-overflow:clip;" x="185.78571428571428">Monday</text><text opacity="1" y="378" transform="translate(0,0)" text-anchor="middle" style="color:#606060;cursor:default;font-size:11px;fill:#606060;width:213px;text-overflow:clip;" x="399.3571428571429">Tuesday</text><text opacity="1" y="378" transform="translate(0,0)" text-anchor="middle" style="color:#606060;cursor:default;font-size:11px;fill:#606060;width:213px;text-overflow:clip;" x="612.9285714285714">Wednesday</text><text opacity="1" y="378" transform="translate(0,0)" text-anchor="middle" style="color:#606060;cursor:default;font-size:11px;fill:#606060;width:213px;text-overflow:clip;" x="826.5">Thursday</text><text opacity="1" y="378" transform="translate(0,0)" text-anchor="middle" style="color:#606060;cursor:default;font-size:11px;fill:#606060;width:213px;text-overflow:clip;" x="1040.0714285714287">Friday</text><text opacity="1" y="378" transform="translate(0,0)" text-anchor="middle" style="color:#606060;cursor:default;font-size:11px;fill:#606060;width:213px;text-overflow:clip;" x="1253.642857142857">Saturday</text><text opacity="1" y="378" transform="translate(0,0)" text-anchor="middle" style="color:#606060;cursor:default;font-size:11px;fill:#606060;width:213px;text-overflow:clip;" x="1467.2142857142858">Sunday</text></g><g zIndex="7" class="highcharts-axis-labels highcharts-yaxis-labels"><text opacity="1" y="361" transform="translate(0,0)" text-anchor="end" style="color:#606060;cursor:default;font-size:11px;fill:#606060;width:513px;text-overflow:clip;" x="64">0</text><text opacity="1" y="310" transform="translate(0,0)" text-anchor="end" style="color:#606060;cursor:default;font-size:11px;fill:#606060;width:513px;text-overflow:clip;" x="64">2.5</text><text opacity="1" y="259" transform="translate(0,0)" text-anchor="end" style="color:#606060;cursor:default;font-size:11px;fill:#606060;width:513px;text-overflow:clip;" x="64">5</text><text opacity="1" y="208" transform="translate(0,0)" text-anchor="end" style="color:#606060;cursor:default;font-size:11px;fill:#606060;width:513px;text-overflow:clip;" x="64">7.5</text><text opacity="1" y="157" transform="translate(0,0)" text-anchor="end" style="color:#606060;cursor:default;font-size:11px;fill:#606060;width:513px;text-overflow:clip;" x="64">10</text><text opacity="1" y="106" transform="translate(0,0)" text-anchor="end" style="color:#606060;cursor:default;font-size:11px;fill:#606060;width:513px;text-overflow:clip;" x="64">12.5</text><text opacity="1" y="55" transform="translate(0,0)" text-anchor="end" style="color:#606060;cursor:default;font-size:11px;fill:#606060;width:513px;text-overflow:clip;" x="64">15</text></g><g visibility="visible" opacity="1" transform="translate(919,226)" style="cursor:default;padding:0;pointer-events:none;white-space:nowrap;" zIndex="8" class="highcharts-tooltip"><path transform="translate(1, 1)" stroke-width="5" stroke-opacity="0.049999999999999996" stroke="black" isShadow="true" d="M 3.5 0.5 L 102.5 0.5 C 105.5 0.5 105.5 0.5 105.5 3.5 L 105.5 60.5 C 105.5 63.5 105.5 63.5 102.5 63.5 L 3.5 63.5 C 0.5 63.5 0.5 63.5 0.5 60.5 L 0.5 3.5 C 0.5 0.5 0.5 0.5 3.5 0.5" fill="none"></path><path transform="translate(1, 1)" stroke-width="3" stroke-opacity="0.09999999999999999" stroke="black" isShadow="true" d="M 3.5 0.5 L 102.5 0.5 C 105.5 0.5 105.5 0.5 105.5 3.5 L 105.5 60.5 C 105.5 63.5 105.5 63.5 102.5 63.5 L 3.5 63.5 C 0.5 63.5 0.5 63.5 0.5 60.5 L 0.5 3.5 C 0.5 0.5 0.5 0.5 3.5 0.5" fill="none"></path><path transform="translate(1, 1)" stroke-width="1" stroke-opacity="0.15" stroke="black" isShadow="true" d="M 3.5 0.5 L 102.5 0.5 C 105.5 0.5 105.5 0.5 105.5 3.5 L 105.5 60.5 C 105.5 63.5 105.5 63.5 102.5 63.5 L 3.5 63.5 C 0.5 63.5 0.5 63.5 0.5 60.5 L 0.5 3.5 C 0.5 0.5 0.5 0.5 3.5 0.5" fill="none"></path><path stroke-width="1" stroke="#7cb5ec" d="M 3.5 0.5 L 102.5 0.5 C 105.5 0.5 105.5 0.5 105.5 3.5 L 105.5 60.5 C 105.5 63.5 105.5 63.5 102.5 63.5 L 3.5 63.5 C 0.5 63.5 0.5 63.5 0.5 60.5 L 0.5 3.5 C 0.5 0.5 0.5 0.5 3.5 0.5" fill="rgba(249, 249, 249, .85)"></path><text y="20" style="font-size:12px;color:#333333;fill:#333333;" zIndex="1" x="8"><tspan style="font-size: 10px">Friday</tspan><tspan dy="15" x="8" style="fill:#7cb5ec">●</tspan><tspan dx="0"> John: </tspan><tspan dx="0" style="font-weight:bold">4 units</tspan><tspan dy="15" x="8" style="fill:#434348">●</tspan><tspan dx="0"> Jane: </tspan><tspan dx="0" style="font-weight:bold">3 units</tspan></text></g></svg></div></div>

	

</body></html>