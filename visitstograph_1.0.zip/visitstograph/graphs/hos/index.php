<?php 
include('../../config.php');
if(isset($_GET['m']) && ($_GET['m'] == '01')) { $month = "janvier"; } if(isset($_GET['m']) && ($_GET['m'] == '02')) { $month = "février"; } if(isset($_GET['m']) && ($_GET['m'] == '03')) { $month = "mars"; } if(isset($_GET['m']) && ($_GET['m'] == '04')) { $month = "avril"; } if(isset($_GET['m']) && ($_GET['m'] == '05')) { $month = "mai"; } if(isset($_GET['m']) && ($_GET['m'] == '06')) { $month = "juin"; } if(isset($_GET['m']) && ($_GET['m'] == '07')) { $month = "juillet"; } if(isset($_GET['m']) && ($_GET['m'] == '08')) { $month = "août"; } if(isset($_GET['m']) && ($_GET['m'] == '09')) { $month = "septembre"; } if(isset($_GET['m']) && ($_GET['m'] == '10')) { $month = "octobre"; } if(isset($_GET['m']) && ($_GET['m'] == '11')) { $month = "novembre"; } if(isset($_GET['m']) && ($_GET['m'] == '12')) { $month = "décembre"; }
if(isset($_GET['mode']) && ($_GET['mode'] == 'day')) { $date1 = 'par jour en '.$month.' '.$_GET['y']; } else if(isset($_GET['mode']) && ($_GET['mode'] == 'month')) { $date1 = 'par mois de l\'année '.$_GET['y']; } else if(isset($_GET['mode']) && ($_GET['mode'] == 'year')) { $date1 = " de l'année ".$_GET['y']; } 
?>
<!DOCTYPE html>
<!--[if IE 8]> <html lang="en" class="ie8"> <![endif]-->
<!--[if IE 9]> <html lang="en" class="ie9"> <![endif]-->
<!--[if !IE]><!-->
<html lang="en"><!--<![endif]--><!-- BEGIN HEAD --><head>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
        <meta charset="utf-8">
    <title>Visiteurs de <?php echo $nomdusite.' '.$date1; ?></title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta content="" name="description">
    <meta content="" name="author">
    <!-- BEGIN GLOBAL MANDATORY STYLES -->
    <link href="index_fichiers/pace.css" rel="stylesheet">
                <link href="index_fichiers/minify.css" rel="stylesheet" type="text/css">
                <link href="index_fichiers/light.css" rel="stylesheet" type="text/css" id="style_color">
    
    <link href="index_fichiers/css.css" rel="stylesheet" type="text/css">
        <!-- END PAGE LEVEL STYLES -->
    <link rel="shortcut icon" href="https://d2599kud7uucku.cloudfront.net/themes/h2/favicon.ico?v=2">
        <!-- BEGIN CORE PLUGINS -->
    <script src="index_fichiers/jquery-1.js" type="text/javascript"></script>
    <script src="index_fichiers/jquery-migrate-1.js" type="text/javascript"></script>
    <!-- IMPORTANT! Load jquery-ui-1.10.1.custom.min.js before bootstrap.min.js to fix bootstrap tooltip conflict with jquery ui tooltip -->
    <script src="index_fichiers/jquery-ui-1.js" type="text/javascript"></script>
    <!--[if lt IE 9]>
    <script src="https://d2599kud7uucku.cloudfront.net/themes/h2/plugins/excanvas.min.js?v=2"></script>
    <script src="https://d2599kud7uucku.cloudfront.net/themes/h2/plugins/respond.min.js?v=2"></script>
    <![endif]-->
    <script src="index_fichiers/jquery_005.js" type="text/javascript"></script>
    <script src="index_fichiers/jquery_004.js" type="text/javascript"></script>
    <!-- END CORE PLUGINS -->

    <!-- BEGIN PAGE LEVEL PLUGINS -->
    <script type="text/javascript" src="index_fichiers/select2.js"></script>
    <script type="text/javascript" src="index_fichiers/jquery.js"></script>
    <script type="text/javascript" src="index_fichiers/jquery_010.js"></script>

    <!-- END PAGE LEVEL SCRIPTS -->
    </head>
<!-- END HEAD -->
<!-- BEGIN BODY -->




<!-- BEGIN HEADER -->
    
<!-- BEGIN TOP NAVIGATION BAR -->

<!-- END TOP NAVIGATION BAR -->

            <!-- END PAGE HEADER-->
            <!-- BEGIN PAGE CONTENT-->
                        
            
    

<body><div class="portlet box green">
    <div class="portlet-title">
        <div class="caption">Visiteurs de <?php echo $nomdusite.' '.$date1; ?></div>
    </div>
    <div class="portlet-body">
        <div style="padding: 0px; position: relative;" id="pageviews" class="chart"><canvas height="300" width="1578" style="direction: ltr; position: absolute; left: 0px; top: 0px; width: 1578px; height: 300px;" class="flot-base"></canvas><div style="position: absolute; top: 0px; left: 0px; bottom: 0px; right: 0px; font-size: smaller; color: rgb(84, 84, 84);" class="flot-text"><div style="position: absolute; top: 0px; left: 0px; bottom: 0px; right: 0px; display: block;" class="flot-x-axis flot-x1-axis xAxis x1Axis"><div class="flot-tick-label tickLabel" style="position: absolute; max-width: 92px; top: 280px; left: 105px; text-align: center;">2</div><div class="flot-tick-label tickLabel" style="position: absolute; max-width: 92px; top: 280px; left: 206px; text-align: center;">4</div><div class="flot-tick-label tickLabel" style="position: absolute; max-width: 92px; top: 280px; left: 307px; text-align: center;">6</div><div class="flot-tick-label tickLabel" style="position: absolute; max-width: 92px; top: 280px; left: 408px; text-align: center;">8</div><div class="flot-tick-label tickLabel" style="position: absolute; max-width: 92px; top: 280px; left: 506px; text-align: center;">10</div><div class="flot-tick-label tickLabel" style="position: absolute; max-width: 92px; top: 280px; left: 607px; text-align: center;">12</div><div class="flot-tick-label tickLabel" style="position: absolute; max-width: 92px; top: 280px; left: 708px; text-align: center;">14</div><div class="flot-tick-label tickLabel" style="position: absolute; max-width: 92px; top: 280px; left: 809px; text-align: center;">16</div><div class="flot-tick-label tickLabel" style="position: absolute; max-width: 92px; top: 280px; left: 909px; text-align: center;">18</div><div class="flot-tick-label tickLabel" style="position: absolute; max-width: 92px; top: 280px; left: 1010px; text-align: center;">20</div><div class="flot-tick-label tickLabel" style="position: absolute; max-width: 92px; top: 280px; left: 1111px; text-align: center;">22</div><div class="flot-tick-label tickLabel" style="position: absolute; max-width: 92px; top: 280px; left: 1212px; text-align: center;">24</div><div class="flot-tick-label tickLabel" style="position: absolute; max-width: 92px; top: 280px; left: 1313px; text-align: center;">26</div><div class="flot-tick-label tickLabel" style="position: absolute; max-width: 92px; top: 280px; left: 1413px; text-align: center;">28</div><div class="flot-tick-label tickLabel" style="position: absolute; max-width: 92px; top: 280px; left: 1514px; text-align: center;">30</div></div><div style="position: absolute; top: 0px; left: 0px; bottom: 0px; right: 0px; display: block;" class="flot-y-axis flot-y1-axis yAxis y1Axis"><div class="flot-tick-label tickLabel" style="position: absolute; top: 265px; left: 47px; text-align: right;">0</div><div class="flot-tick-label tickLabel" style="position: absolute; top: 241px; left: 42px; text-align: right;">25</div><div class="flot-tick-label tickLabel" style="position: absolute; top: 217px; left: 42px; text-align: right;">50</div><div class="flot-tick-label tickLabel" style="position: absolute; top: 193px; left: 42px; text-align: right;">75</div><div class="flot-tick-label tickLabel" style="position: absolute; top: 169px; left: 36px; text-align: right;">100</div><div class="flot-tick-label tickLabel" style="position: absolute; top: 145px; left: 36px; text-align: right;">125</div><div class="flot-tick-label tickLabel" style="position: absolute; top: 120px; left: 36px; text-align: right;">150</div><div class="flot-tick-label tickLabel" style="position: absolute; top: 96px; left: 36px; text-align: right;">175</div><div class="flot-tick-label tickLabel" style="position: absolute; top: 72px; left: 36px; text-align: right;">200</div><div class="flot-tick-label tickLabel" style="position: absolute; top: 48px; left: 36px; text-align: right;">225</div><div class="flot-tick-label tickLabel" style="position: absolute; top: 24px; left: 36px; text-align: right;">250</div><div class="flot-tick-label tickLabel" style="position: absolute; top: 0px; left: 0px; text-align: right;">Utilisateurs</div></div></div><canvas height="300" width="1578" style="direction: ltr; position: absolute; left: 0px; top: 0px; width: 1578px; height: 300px;" class="flot-overlay"></canvas><div class="legend"><div style="position: absolute; width: 62px; height: 22px; top: 15px; right: 13px; background-color: rgb(255, 255, 255); opacity: 0.85;"> </div><table style="position:absolute;top:15px;right:13px;;font-size:smaller;color:#545454"><tbody><tr><td class="legendColorBox"><div style="border:1px solid #ccc;padding:1px"><div style="width:4px;height:0;border:5px solid rgb(102,102,102);overflow:hidden"></div></div></td><td class="legendLabel">Visiteurs</td></tr></tbody></table></div></div>
    </div>
</div>



<script src="index_fichiers/charts.js" type="text/javascript"></script>
<script src="index_fichiers/jquery_007.js" type="text/javascript"></script>
<script src="index_fichiers/jquery_003.js" type="text/javascript"></script>
<script src="index_fichiers/jquery_009.js" type="text/javascript"></script>
<script src="index_fichiers/jquery_008.js" type="text/javascript"></script>
<script src="index_fichiers/jquery_006.js" type="text/javascript"></script>
<script src="index_fichiers/jquery_002.js" type="text/javascript"></script>
<script type="text/javascript">
try{Charts.init();} catch (e){}
try{Charts.initCharts();} catch (e){}

    
    function bandwidth() {

        var pageviews = [];

                                                          
                    
        var plot = $.plot($("#bandwidth"), [{
            data: pageviews,
            label: "pageviews Bandwidth"
        }
        ], {
            series: {
                lines: {
                    show: true,
                    lineWidth: 2,
                    fill: true,
                    fillColor: {
                        colors: [{
                            opacity: 0.05
                        }, {
                            opacity: 0.01
                        }
                        ]
                    }
                },
                points: {
                    show: true
                },
                shadowSize: 2
            },
            grid: {
                hoverable: true,
                clickable: true,
                tickColor: "#eee",
                borderWidth: 0
            },
            colors: ["#37b7f3", "#52e136"],
            xaxis: {
                ticks: 11,
                tickDecimals: 0,
                max: 30,
                tickFormatter: function(val, axis) { return val < axis.max ? val.toFixed(0) : "Jour";}

            },
            yaxis: {
                ticks: 11,
                tickDecimals: 0,
                min: 0,
                tickFormatter: function(val, axis) { return val < axis.max ? val.toFixed(0) : "MB";}

            }
        });


        function showTooltip(x, y, contents) {
            $('<div id="tooltip">' + contents + '</div>').css({
                position: 'absolute',
                display: 'none',
                top: y + 5,
                left: x + 15,
                border: '1px solid #333',
                padding: '4px',
                color: '#fff',
                'border-radius': '3px',
                'background-color': '#333',
                opacity: 0.80
            }).appendTo("body").fadeIn(200);
        }

        var previousPoint = null;
        $("#bandwidth").bind("plothover", function (event, pos, item) {
            $("#x").text(pos.x.toFixed(2));
            $("#y").text(pos.y.toFixed(2));

            if (item) {
                if (previousPoint != item.dataIndex) {
                    previousPoint = item.dataIndex;

                    $("#tooltip").remove();
                    var x = item.datapoint[0].toFixed(2),
                        y = item.datapoint[1].toFixed(2);

                    showTooltip(item.pageX, item.pageY, item.series.label + ": " + y + "MB");
                }
            } else {
                $("#tooltip").remove();
                previousPoint = null;
            }
        });
    }

    
    function pageviews() {

        var pageviews = [];		                                <?php if(isset($_GET['mode']) && ($_GET['mode'] == "day")) { ?>
        <?php $annee=filter_var($_GET['y'], FILTER_SANITIZE_NUMBER_INT);
$mois=filter_var($_GET['m'], FILTER_SANITIZE_NUMBER_INT);
for ($jour=1; $jour <= cal_days_in_month(CAL_GREGORIAN, (int) $mois, $annee); $jour++) {
if($jour<10) { $jour = '0'.$jour; }
  // 3) On récupère le nombre de visites ce jour
  $nb_visites = @file_get_contents($urlcompteur.$jour.'-'.$mois.'-'.$annee);
  // 4) si on n'obtient rien, c'est probablement que le fichier n'existe pas et on le met donc à 0
  if (empty($nb_visites)) $nb_visites = 0;

  // 5) On affiche la ligne pour le jour concerné
			print "pageviews.push([".$jour.",".$nb_visites."]);\r\n"; } ?>
		<?php } ?>
		
		<?php if(isset($_GET['mode']) && ($_GET['mode'] == "month")) { ?>
                pageviews.push([1,<?php echo '0'. @file_get_contents($urlcompteur.'01-'.$_GET['y']); ?>]);
				pageviews.push([2,<?php echo '0'. @file_get_contents($urlcompteur.'02-'.$_GET['y']); ?>]);
				pageviews.push([3,<?php echo '0'. @file_get_contents($urlcompteur.'03-'.$_GET['y']); ?>]);
				pageviews.push([4,<?php echo '0'. @file_get_contents($urlcompteur.'04-'.$_GET['y']); ?>]);
			    pageviews.push([5,<?php echo '0'. @file_get_contents($urlcompteur.'05-'.$_GET['y']); ?>]);
				pageviews.push([6,<?php echo '0'. @file_get_contents($urlcompteur.'06-'.$_GET['y']); ?>]);
				pageviews.push([7,<?php echo '0'. @file_get_contents($urlcompteur.'07-'.$_GET['y']); ?>]);
				pageviews.push([8,<?php echo '0'. @file_get_contents($urlcompteur.'08-'.$_GET['y']); ?>]);
				pageviews.push([9,<?php echo '0'. @file_get_contents($urlcompteur.'09-'.$_GET['y']); ?>]);
				pageviews.push([10,<?php echo '0'. @file_get_contents($urlcompteur.'10-'.$_GET['y']); ?>]);
				pageviews.push([11,<?php echo '0'. @file_get_contents($urlcompteur.'11-'.$_GET['y']); ?>]);
				pageviews.push([12,<?php echo '0'. @file_get_contents($urlcompteur.'12-'.$_GET['y']); ?>]);
             
            
			<?php } ?>
																	
                    
        var plot = $.plot($("#pageviews"), [{
            data: pageviews,
            label: "Visiteurs"
        }
        ], {
            series: {
                lines: {
                    show: true,
                    lineWidth: 2,
                    fill: true,
                    fillColor: {
                        colors: [{
                            opacity: 0.02
                        }, {
                            opacity: 0.01
                        }
                        ]
                    }
                },
                points: {
                    show: true
                },
                shadowSize: 2
            },
            grid: {
                hoverable: true,
                clickable: true,
                tickColor: "#eee",
                borderWidth: 0
            },

            colors: ["<?php echo $_GET['color']; ?>", "#37b7f3", "#52e136"],
            xaxis: {
                ticks: 11,
                tickDecimals: 0,
                max: <?php
if(isset($_GET['mode']) && ($_GET['mode'] == "day")) {
$number = cal_days_in_month(CAL_GREGORIAN, $_GET['m'], $_GET['y']);
echo $number; } else { echo '12'; }
?>,
                tickFormatter: function(val, axis) { return val < axis.max ? val.toFixed(0) : "<?php if(isset($_GET['mode']) && ($_GET['mode'] == "day")) { echo 'Jours'; } else { echo 'Mois'; } ?>";}

            },
            yaxis: {
                ticks: 11,
                tickDecimals: 0,
                min: 0,
                tickFormatter: function(val, axis) { return val < axis.max ? val.toFixed(0) : "Visiteurs";}

            }
        });


        function showTooltip(x, y, contents) {
            $('<div id="tooltip">' + contents + '</div>').css({
                position: 'absolute',
                display: 'none',
                top: y + 5,
                left: x + 13,
                border: '1px solid #333',
                padding: '4px',
                color: '#fff',
                'border-radius': '3px',
                'background-color': '#333',
                opacity: 0.80
            }).appendTo("body").fadeIn(200);
        }

        var previousPoint = null;
        $("#pageviews").bind("plothover", function (event, pos, item) {
            $("#x").text(pos.x.toFixed(2));
            $("#y").text(pos.y.toFixed(2));

            if (item) {
                if (previousPoint != item.dataIndex) {
                    previousPoint = item.dataIndex;

                    $("#tooltip").remove();
                    var x = item.datapoint[0].toFixed(0),
                        y = item.datapoint[1].toFixed(0);

                    showTooltip(item.pageX, item.pageY, item.series.label + ": " + y);
                }
            } else {
                $("#tooltip").remove();
                previousPoint = null;
            }
        });
    }

</script>            <!-- END PAGE CONTENT-->
        
<!-- BEGIN CONTAINER -->

</body><!-- END BODY --></html>