<?php 
include('../../config.php');
if(isset($_GET['m']) && ($_GET['m'] == '01')) { $month = "janvier"; } if(isset($_GET['m']) && ($_GET['m'] == '02')) { $month = "février"; } if(isset($_GET['m']) && ($_GET['m'] == '03')) { $month = "mars"; } if(isset($_GET['m']) && ($_GET['m'] == '04')) { $month = "avril"; } if(isset($_GET['m']) && ($_GET['m'] == '05')) { $month = "mai"; } if(isset($_GET['m']) && ($_GET['m'] == '06')) { $month = "juin"; } if(isset($_GET['m']) && ($_GET['m'] == '07')) { $month = "juillet"; } if(isset($_GET['m']) && ($_GET['m'] == '08')) { $month = "août"; } if(isset($_GET['m']) && ($_GET['m'] == '09')) { $month = "septembre"; } if(isset($_GET['m']) && ($_GET['m'] == '10')) { $month = "octobre"; } if(isset($_GET['m']) && ($_GET['m'] == '11')) { $month = "novembre"; } if(isset($_GET['m']) && ($_GET['m'] == '12')) { $month = "décembre"; }
if(isset($_GET['mode']) && ($_GET['mode'] == 'day')) { $date1 = 'par jour en '.$month.' '.$_GET['y']; } else if(isset($_GET['mode']) && ($_GET['mode'] == 'month')) { $date1 = 'par mois de l\\\'année '.$_GET['y']; } else if(isset($_GET['mode']) && ($_GET['mode'] == 'year')) { $date1 = " de l\'année ".$_GET['y']; } 
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<html><head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>Visiteurs de <?php echo $nomdusite.' '.$date1; ?></title>
        <link rel="stylesheet" href="index_fichiers/style.css" type="text/css">
        <script src="index_fichiers/amcharts.js" type="text/javascript"></script>
        <script src="index_fichiers/pie.js" type="text/javascript"></script>

        <script>
            var chart;
            var legend;

            var chartData = [
               <?php if(isset($_GET['mode']) && ($_GET['mode'] == "day")) { ?>
        <?php $annee=filter_var($_GET['y'], FILTER_SANITIZE_NUMBER_INT);
$mois=filter_var($_GET['m'], FILTER_SANITIZE_NUMBER_INT);
for ($jour=1; $jour <= cal_days_in_month(CAL_GREGORIAN, (int) $mois, $annee); $jour++) {
if($jour<10) { $jour = '0'.$jour; }
  // 3) On récupère le nombre de visites ce jour
  $nb_visites = @file_get_contents($urlcompteur.$jour.'-'.$mois.'-'.$annee);
  // 4) si on n'obtient rien, c'est probablement que le fichier n'existe pas et on le met donc à 0
  if (empty($nb_visites)) $nb_visites = 0;

  // 5) On affiche la ligne pour le jour concerné
			print "{
                    \"country\": \"".$jour."/".$mois."/".$annee.'",
                    "visits": '.$nb_visites."},\r\n"; } ?>
		<?php } ?>
		<?php if(isset($_GET['mode']) && ($_GET['mode'] == "month")) { ?>
            
                {
                    "country": "01/<?php echo $_GET['y']; ?>",
                    "visits": <?php echo '0'. @file_get_contents($urlcompteur.'01-'.$_GET['y']); ?>
                },
				{
                    "country": "02/<?php echo $_GET['y']; ?>",
                    "visits": <?php echo '0'. @file_get_contents($urlcompteur.'02-'.$_GET['y']); ?>
                },
				{
                    "country": "03/<?php echo $_GET['y']; ?>",
                    "visits": <?php echo '0'. @file_get_contents($urlcompteur.'03-'.$_GET['y']); ?>
                },
				{
                    "country": "04/<?php echo $_GET['y']; ?>",
                    "visits": <?php echo '0'. @file_get_contents($urlcompteur.'04-'.$_GET['y']); ?>
                },
				{
                    "country": "05/<?php echo $_GET['y']; ?>",
                    "visits": <?php echo '0'. @file_get_contents($urlcompteur.'05-'.$_GET['y']); ?>
                },
				{
                    "country": "06/<?php echo $_GET['y']; ?>",
                    "visits": <?php echo '0'. @file_get_contents($urlcompteur.'06-'.$_GET['y']); ?>
                },
				{
                    "country": "07/<?php echo $_GET['y']; ?>",
                    "visits": <?php echo '0'. @file_get_contents($urlcompteur.'07-'.$_GET['y']); ?>
                },
				{
                    "country": "08/<?php echo $_GET['y']; ?>",
                    "visits": <?php echo '0'. @file_get_contents($urlcompteur.'08-'.$_GET['y']); ?>
                },
				{
                    "country": "09/<?php echo $_GET['y']; ?>",
                    "visits": <?php echo '0'. @file_get_contents($urlcompteur.'09-'.$_GET['y']); ?>
                },
				{
                    "country": "10/<?php echo $_GET['y']; ?>",
                    "visits": <?php echo '0'. @file_get_contents($urlcompteur.'10-'.$_GET['y']); ?>
                },
				{
                    "country": "11/<?php echo $_GET['y']; ?>",
                    "visits": <?php echo '0'. @file_get_contents($urlcompteur.'11-'.$_GET['y']); ?>
                },
				{
                    "country": "12/<?php echo $_GET['y']; ?>",
                    "visits": <?php echo '0'. @file_get_contents($urlcompteur.'12-'.$_GET['y']); ?>
                },
				
			<?php } ?>
            ];

            AmCharts.ready(function () {
                // PIE CHART
                chart = new AmCharts.AmPieChart();
                chart.dataProvider = chartData;
                chart.titleField = "country";
                chart.valueField = "visits";
                chart.outlineColor = "#FFFFFF";
                chart.outlineAlpha = 0.8;
                chart.outlineThickness = 2;
                chart.balloonText = "[[title]]<br><span style='font-size:14px'><b>[[value]]</b> ([[percents]]%)</span>";
                // this makes the chart 3D
                chart.depth3D = 15;
                chart.angle = 30;

                // WRITE
                chart.write("chartdiv");
            });
        </script>
    </head>

    <body>
        <div id="chartdiv" style="width: 100%; height: 400px; overflow: hidden; text-align: left;"><div class="amcharts-main-div" style="position: relative;"><div class="amcharts-chart-div" style="overflow: hidden; position: relative; text-align: left; width: 1584px; height: 400px; padding: 0px;"><svg style="position: absolute; width: 1584px; height: 400px; top: 0px; left: 0px;" version="1.1"><desc>JavaScript chart by amCharts 3.19.2</desc><g><path stroke-opacity="0" stroke-width="1" fill-opacity="0" stroke="#000000" fill="#FFFFFF" d="M0.5,0.5 L1583.5,0.5 L1583.5,399.5 L0.5,399.5 Z" cs="100,100"></path></g><g></g><g></g><g></g><g></g><g></g><g><g transform="translate(0,0)" visibility="visible" opacity="1"><path transform="translate(0,0)" fill-opacity="1" stroke-opacity="0" fill="#8db207" d=" M792,215 L774.6848168117713,105.61481514794627 A164,110,0,0,1,791.9999999999998,105 L792,215 Z" cs="1000,1000"></path><path transform="translate(0,-10)" fill-opacity="1" stroke-opacity="0" fill="#8db207" d=" M792,215 L774.6848168117713,105.61481514794627 A164,110,0,0,1,791.9999999999998,105 L792,215 Z" cs="1000,1000"></path><path fill-opacity="1" stroke-opacity="0" fill="#8db207" d=" M792,200 L792,215 L774.6848168117713,105.61481514794627 L774.6848168117713,90.61481514794627 L792,200 Z" cs="1000,1000"></path><path fill-opacity="1" stroke-opacity="0" fill="#8db207" d=" M791.9999999999998,90 L791.9999999999998,105 L792,215 L792,200 L791.9999999999998,90 Z" cs="1000,1000"></path><path fill-opacity="1" stroke-opacity="0.8" stroke-width="2" stroke="#FFFFFF" fill="#B0DE09" d=" M792,200 L774.6848168117713,90.61481514794627 A164,110,0,0,1,791.9999999999998,90 L792,200 Z" cs="1000,1000"></path><path visibility="visible" stroke="#000000" stroke-opacity="0.2" fill="none" d="M783.5,91.5 L782.5,51.5 L774.5,51.5" cs="100,100"></path></g><g transform="translate(0,0)" visibility="visible" opacity="1"><path transform="translate(0,0)" fill-opacity="1" stroke-opacity="0" fill="#c6cc01" d=" M792,215 L742.4774843112781,110.13496299478031 A164,110,0,0,1,774.6848168117713,105.61481514794627 L792,215 Z" cs="1000,1000"></path><path transform="translate(0,-10)" fill-opacity="1" stroke-opacity="0" fill="#c6cc01" d=" M792,215 L742.4774843112781,110.13496299478031 A164,110,0,0,1,774.6848168117713,105.61481514794627 L792,215 Z" cs="1000,1000"></path><path fill-opacity="1" stroke-opacity="0" fill="#c6cc01" d=" M792,200 L792,215 L742.4774843112781,110.13496299478031 L742.4774843112781,95.13496299478031 L792,200 Z" cs="1000,1000"></path><path fill-opacity="1" stroke-opacity="0" fill="#c6cc01" d=" M774.6848168117713,90.61481514794627 L774.6848168117713,105.61481514794627 L792,215 L792,200 L774.6848168117713,90.61481514794627 Z" cs="1000,1000"></path><path fill-opacity="1" stroke-opacity="0.8" stroke-width="2" stroke="#FFFFFF" fill="#F8FF01" d=" M792,200 L742.4774843112781,95.13496299478031 A164,110,0,0,1,774.6848168117713,90.61481514794627 L792,200 Z" cs="1000,1000"></path><path visibility="visible" stroke="#000000" stroke-opacity="0.2" fill="none" d="M758.5,93.5 L754.5,72.5 L746.5,72.5" cs="100,100"></path></g><g transform="translate(0,0)" visibility="visible" opacity="1"><path transform="translate(0,0)" fill-opacity="1" stroke-opacity="0" fill="#caa802" d=" M792,215 L683.9488259002705,132.24969027323635 A164,110,0,0,1,742.4774843112781,110.13496299478031 L792,215 Z" cs="1000,1000"></path><path transform="translate(0,-10)" fill-opacity="1" stroke-opacity="0" fill="#caa802" d=" M792,215 L683.9488259002705,132.24969027323635 A164,110,0,0,1,742.4774843112781,110.13496299478031 L792,215 Z" cs="1000,1000"></path><path fill-opacity="1" stroke-opacity="0" fill="#caa802" d=" M792,200 L792,215 L683.9488259002705,132.24969027323635 L683.9488259002705,117.24969027323634 L792,200 Z" cs="1000,1000"></path><path fill-opacity="1" stroke-opacity="0" fill="#caa802" d=" M742.4774843112781,95.13496299478031 L742.4774843112781,110.13496299478031 L792,215 L792,200 L742.4774843112781,95.13496299478031 Z" cs="1000,1000"></path><path fill-opacity="1" stroke-opacity="0.8" stroke-width="2" stroke="#FFFFFF" fill="#FCD202" d=" M792,200 L683.9488259002705,117.24969027323634 A164,110,0,0,1,742.4774843112781,95.13496299478031 L792,200 Z" cs="1000,1000"></path><path visibility="visible" stroke="#000000" stroke-opacity="0.2" fill="none" d="M711.5,105.5 L701.5,93.5 L693.5,93.5" cs="100,100"></path></g><g transform="translate(0,0)" visibility="visible" opacity="1"><path transform="translate(0,0)" fill-opacity="1" stroke-opacity="0" fill="#cc7e01" d=" M792,215 L630.1993331020528,197.04562354226152 A164,110,0,0,1,683.9488259002705,132.24969027323635 L792,215 Z" cs="1000,1000"></path><path transform="translate(0,-10)" fill-opacity="1" stroke-opacity="0" fill="#cc7e01" d=" M792,215 L630.1993331020528,197.04562354226152 A164,110,0,0,1,683.9488259002705,132.24969027323635 L792,215 Z" cs="1000,1000"></path><path fill-opacity="1" stroke-opacity="0" fill="#cc7e01" d=" M792,200 L792,215 L630.1993331020528,197.04562354226152 L630.1993331020528,182.04562354226152 L792,200 Z" cs="1000,1000"></path><path fill-opacity="1" stroke-opacity="0" fill="#cc7e01" d=" M683.9488259002705,117.24969027323634 L683.9488259002705,132.24969027323635 L792,215 L792,200 L683.9488259002705,117.24969027323634 Z" cs="1000,1000"></path><path fill-opacity="1" stroke-opacity="0.8" stroke-width="2" stroke="#FFFFFF" fill="#FF9E01" d=" M792,200 L630.1993331020528,182.04562354226152 A164,110,0,0,1,683.9488259002705,117.24969027323634 L792,200 Z" cs="1000,1000"></path><path visibility="visible" stroke="#000000" stroke-opacity="0.2" fill="none" d="M648.5,147.5 L631.5,140.5 L623.5,140.5" cs="100,100"></path></g><g transform="translate(0,0)" visibility="visible" opacity="1"><path transform="translate(0,0)" fill-opacity="1" stroke-opacity="0" fill="#cc0c00" d=" M792,215 L792,105 A164,110,0,0,1,854.5596904301932,316.6823187739361 L792,215 Z" cs="1000,1000"></path><path transform="translate(0,-10)" fill-opacity="1" stroke-opacity="0" fill="#cc0c00" d=" M792,215 L792,105 A164,110,0,0,1,854.5596904301932,316.6823187739361 L792,215 Z" cs="1000,1000"></path><path fill-opacity="1" stroke-opacity="0" fill="#cc0c00" d=" M792,200 L792,215 L792,105 L792,90 L792,200 Z" cs="1000,1000"></path><path fill-opacity="1" stroke-opacity="0" fill="#cc0c00" d=" M854.5596904301932,301.6823187739361 L854.5596904301932,316.6823187739361 L792,215 L792,200 L854.5596904301932,301.6823187739361 Z" cs="1000,1000"></path><path fill-opacity="1" stroke-opacity="0.8" stroke-width="2" stroke="#FFFFFF" fill="#FF0F00" d=" M792,200 L792,90 A164,110,0,0,1,854.5596904301932,301.6823187739361 L792,200 Z" cs="1000,1000"></path><path visibility="visible" stroke="#000000" stroke-opacity="0.2" fill="none" d="M953.5,179.5 L973.5,176.5 L981.5,176.5" cs="100,100"></path></g><g transform="translate(0,0)" visibility="visible" opacity="1"><path transform="translate(0,0)" fill-opacity="1" stroke-opacity="0" fill="#cc5200" d=" M792,215 L854.5596904301932,316.6823187739361 A164,110,0,0,1,630.1993331020528,197.04562354226152 L792,215 Z" cs="1000,1000"></path><path transform="translate(0,-10)" fill-opacity="1" stroke-opacity="0" fill="#cc5200" d=" M792,215 L854.5596904301932,316.6823187739361 A164,110,0,0,1,630.1993331020528,197.04562354226152 L792,215 Z" cs="1000,1000"></path><path fill-opacity="1" stroke-opacity="0" fill="#cc5200" d=" M792,200 L792,215 L854.5596904301932,316.6823187739361 L854.5596904301932,301.6823187739361 L792,200 Z" cs="1000,1000"></path><path fill-opacity="1" stroke-opacity="0" fill="#cc5200" d=" M630.1993331020528,182.04562354226152 L630.1993331020528,197.04562354226152 L792,215 L792,200 L630.1993331020528,182.04562354226152 Z" cs="1000,1000"></path><path fill-opacity="1" stroke-opacity="0.8" stroke-width="2" stroke="#FFFFFF" fill="#FF6600" d=" M792,200 L854.5596904301932,301.6823187739361 A164,110,0,0,1,630.1993331020528,182.04562354226152 L792,200 Z" cs="1000,1000"></path><path visibility="visible" stroke="#000000" stroke-opacity="0.2" fill="none" d="M690.5,286.5 L677.5,296.5 L669.5,296.5" cs="100,100"></path></g></g><g></g><g><g opacity="1" transform="translate(0,0)" visibility="visible"><text visibility="visible" style="pointer-events: none;" transform="translate(985,176)" text-anchor="start" opacity="1" font-size="11px" font-family="Verdana" fill="#000000" y="6"><tspan x="0" y="6">Lithuania: 43.77%</tspan></text></g><g opacity="1" transform="translate(0,0)" visibility="visible"><text visibility="visible" style="pointer-events: none;" transform="translate(665,296)" text-anchor="end" opacity="1" font-size="11px" font-family="Verdana" fill="#000000" y="6"><tspan x="0" y="6">Ireland: 33.84%</tspan></text></g><g opacity="1" transform="translate(0,0)" visibility="visible"><text visibility="visible" style="pointer-events: none;" transform="translate(619,140)" text-anchor="end" opacity="1" font-size="11px" font-family="Verdana" fill="#000000" y="6"><tspan x="0" y="6">Germany: 10.94%</tspan></text></g><g opacity="1" transform="translate(0,0)" visibility="visible"><text visibility="visible" style="pointer-events: none;" transform="translate(689,93)" text-anchor="end" opacity="1" font-size="11px" font-family="Verdana" fill="#000000" y="6"><tspan x="0" y="6">Australia: 6.57%</tspan></text></g><g opacity="1" transform="translate(0,0)" visibility="visible"><text visibility="visible" style="pointer-events: none;" transform="translate(742,72)" text-anchor="end" opacity="1" font-size="11px" font-family="Verdana" fill="#000000" y="6"><tspan x="0" y="6">UK: 3.20%</tspan></text></g><g opacity="1" transform="translate(0,0)" visibility="visible"><text visibility="visible" style="pointer-events: none;" transform="translate(770,51)" text-anchor="end" opacity="1" font-size="11px" font-family="Verdana" fill="#000000" y="6"><tspan x="0" y="6">Latvia: 1.68%</tspan></text></g></g><g></g><g></g><g></g><g><g></g></g><g></g><g></g><g></g><g></g><g></g></svg><a style="position: absolute; text-decoration: none; color: rgb(0, 0, 0); font-family: Verdana; font-size: 11px; opacity: 0.7; display: block; left: 5px; top: 5px;" title="JavaScript charts" href="http://www.amcharts.com/javascript-charts/">JS chart by amCharts</a></div></div></div>
    

</body></html>