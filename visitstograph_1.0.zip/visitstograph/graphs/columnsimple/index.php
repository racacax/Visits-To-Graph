<?php 
include('../../config.php');
if(isset($_GET['m']) && ($_GET['m'] == '01')) { $month = "janvier"; } if(isset($_GET['m']) && ($_GET['m'] == '02')) { $month = "février"; } if(isset($_GET['m']) && ($_GET['m'] == '03')) { $month = "mars"; } if(isset($_GET['m']) && ($_GET['m'] == '04')) { $month = "avril"; } if(isset($_GET['m']) && ($_GET['m'] == '05')) { $month = "mai"; } if(isset($_GET['m']) && ($_GET['m'] == '06')) { $month = "juin"; } if(isset($_GET['m']) && ($_GET['m'] == '07')) { $month = "juillet"; } if(isset($_GET['m']) && ($_GET['m'] == '08')) { $month = "août"; } if(isset($_GET['m']) && ($_GET['m'] == '09')) { $month = "septembre"; } if(isset($_GET['m']) && ($_GET['m'] == '10')) { $month = "octobre"; } if(isset($_GET['m']) && ($_GET['m'] == '11')) { $month = "novembre"; } if(isset($_GET['m']) && ($_GET['m'] == '12')) { $month = "décembre"; }
if(isset($_GET['mode']) && ($_GET['mode'] == 'day')) { $date1 = 'par jour en '.$month.' '.$_GET['y']; } else if(isset($_GET['mode']) && ($_GET['mode'] == 'month')) { $date1 = 'par mois de l\\\'année '.$_GET['y']; } else if(isset($_GET['mode']) && ($_GET['mode'] == 'year')) { $date1 = " de l\'année ".$_GET['y']; } 
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<html><head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>Visiteurs de <?php echo $nomdusite.' '.$date1; ?></title>
        <link rel="stylesheet" href="index_fichiers/style.css" type="text/css">
        <script src="index_fichiers/amcharts.js" type="text/javascript"></script>
        <script src="index_fichiers/serial.js" type="text/javascript"></script>

        <script>
            var chart;

            var chartData = [
                <?php if(isset($_GET['mode']) && ($_GET['mode'] == "day")) { ?>
        <?php $annee=filter_var($_GET['y'], FILTER_SANITIZE_NUMBER_INT);
$mois=filter_var($_GET['m'], FILTER_SANITIZE_NUMBER_INT);
for ($jour=1; $jour <= cal_days_in_month(CAL_GREGORIAN, (int) $mois, $annee); $jour++) {
if($jour<10) { $jour = '0'.$jour; }
  // 3) On récupère le nombre de visites ce jour
  $nb_visites = @file_get_contents($urlcompteur.$jour.'-'.$mois.'-'.$annee);
  // 4) si on n'obtient rien, c'est probablement que le fichier n'existe pas et on le met donc à 0
  if (empty($nb_visites)) $nb_visites = 0;

  // 5) On affiche la ligne pour le jour concerné
			print "{
                    \"country\": \"".$jour."/".$mois."/".$annee.'",
                    "visits": '.$nb_visites."},\r\n"; } ?>
		<?php } ?>
		<?php if(isset($_GET['mode']) && ($_GET['mode'] == "month")) { ?>
            
                {
                    "country": "01/<?php echo $_GET['y']; ?>",
                    "visits": <?php echo '0'. @file_get_contents($urlcompteur.'01-'.$_GET['y']); ?>
                },
				{
                    "country": "02/<?php echo $_GET['y']; ?>",
                    "visits": <?php echo '0'. @file_get_contents($urlcompteur.'02-'.$_GET['y']); ?>
                },
				{
                    "country": "03/<?php echo $_GET['y']; ?>",
                    "visits": <?php echo '0'. @file_get_contents($urlcompteur.'03-'.$_GET['y']); ?>
                },
				{
                    "country": "04/<?php echo $_GET['y']; ?>",
                    "visits": <?php echo '0'. @file_get_contents($urlcompteur.'04-'.$_GET['y']); ?>
                },
				{
                    "country": "05/<?php echo $_GET['y']; ?>",
                    "visits": <?php echo '0'. @file_get_contents($urlcompteur.'05-'.$_GET['y']); ?>
                },
				{
                    "country": "06/<?php echo $_GET['y']; ?>",
                    "visits": <?php echo '0'. @file_get_contents($urlcompteur.'06-'.$_GET['y']); ?>
                },
				{
                    "country": "07/<?php echo $_GET['y']; ?>",
                    "visits": <?php echo '0'. @file_get_contents($urlcompteur.'07-'.$_GET['y']); ?>
                },
				{
                    "country": "08/<?php echo $_GET['y']; ?>",
                    "visits": <?php echo '0'. @file_get_contents($urlcompteur.'08-'.$_GET['y']); ?>
                },
				{
                    "country": "09/<?php echo $_GET['y']; ?>",
                    "visits": <?php echo '0'. @file_get_contents($urlcompteur.'09-'.$_GET['y']); ?>
                },
				{
                    "country": "10/<?php echo $_GET['y']; ?>",
                    "visits": <?php echo '0'. @file_get_contents($urlcompteur.'10-'.$_GET['y']); ?>
                },
				{
                    "country": "11/<?php echo $_GET['y']; ?>",
                    "visits": <?php echo '0'. @file_get_contents($urlcompteur.'11-'.$_GET['y']); ?>
                },
				{
                    "country": "12/<?php echo $_GET['y']; ?>",
                    "visits": <?php echo '0'. @file_get_contents($urlcompteur.'12-'.$_GET['y']); ?>
                },
				
			<?php } ?>
            ];


            AmCharts.ready(function () {
                // SERIAL CHART
                chart = new AmCharts.AmSerialChart();
                chart.dataProvider = chartData;
                chart.categoryField = "country";
                chart.startDuration = 1;

                // AXES
                // category
                var categoryAxis = chart.categoryAxis;
                categoryAxis.labelRotation = 90;
                categoryAxis.gridPosition = "start";

                // value
                // in case you don't want to change default settings of value axis,
                // you don't need to create it, as one value axis is created automatically.

                // GRAPH
                var graph = new AmCharts.AmGraph();
                graph.valueField = "visits";
                graph.balloonText = "[[category]]: <b>[[value]]</b>";
                graph.type = "column";
                graph.lineAlpha = 0;
                graph.fillAlphas = 0.8;
                chart.addGraph(graph);

                // CURSOR
                var chartCursor = new AmCharts.ChartCursor();
                chartCursor.cursorAlpha = 0;
                chartCursor.zoomable = false;
                chartCursor.categoryBalloonEnabled = false;
                chart.addChartCursor(chartCursor);

                chart.creditsPosition = "top-right";

                chart.write("chartdiv");
            });
        </script>
    </head>

    <body>
        <div id="chartdiv" style="width: 100%; height: 400px; overflow: hidden; text-align: left;"><div class="amcharts-main-div" style="position: relative;"><div class="amcharts-chart-div" style="overflow: hidden; position: relative; text-align: left; width: 1584px; height: 400px; padding: 0px; cursor: default;"><svg style="position: absolute; width: 1584px; height: 400px; top: 0px; left: 0px;" version="1.1"><desc>JavaScript chart by amCharts 3.19.2</desc><g><path stroke-opacity="0" stroke-width="1" fill-opacity="0" stroke="#000000" fill="#FFFFFF" d="M0.5,0.5 L1583.5,0.5 L1583.5,399.5 L0.5,399.5 Z" cs="100,100"></path><path transform="translate(60,20)" stroke-opacity="0" stroke-width="1" fill-opacity="0" stroke="#000000" fill="#FFFFFF" d="M0.5,0.5 L1503.5,0.5 L1503.5,288.5 L0.5,288.5 L0.5,0.5 Z" cs="100,100"></path></g><g><g transform="translate(60,20)"><g><path transform="translate(0,288)" stroke="#000000" stroke-opacity="1" stroke-width="1" fill="none" d="M44.5,0.5 L44.5,5.5" cs="100,100"></path><path stroke="#000000" stroke-opacity="0.15" stroke-width="1" fill="none" d="M0.5,288.5 L0.5,288.5 L0.5,0.5" cs="100,100"></path></g><g><path transform="translate(0,288)" stroke="#000000" stroke-opacity="1" stroke-width="1" fill="none" d="M133.5,0.5 L133.5,5.5" cs="100,100"></path><path stroke="#000000" stroke-opacity="0.15" stroke-width="1" fill="none" d="M89.5,288.5 L89.5,288.5 L89.5,0.5" cs="100,100"></path></g><g><path transform="translate(0,288)" stroke="#000000" stroke-opacity="1" stroke-width="1" fill="none" d="M221.5,0.5 L221.5,5.5" cs="100,100"></path><path stroke="#000000" stroke-opacity="0.15" stroke-width="1" fill="none" d="M177.5,288.5 L177.5,288.5 L177.5,0.5" cs="100,100"></path></g><g><path transform="translate(0,288)" stroke="#000000" stroke-opacity="1" stroke-width="1" fill="none" d="M309.5,0.5 L309.5,5.5" cs="100,100"></path><path stroke="#000000" stroke-opacity="0.15" stroke-width="1" fill="none" d="M265.5,288.5 L265.5,288.5 L265.5,0.5" cs="100,100"></path></g><g><path transform="translate(0,288)" stroke="#000000" stroke-opacity="1" stroke-width="1" fill="none" d="M398.5,0.5 L398.5,5.5" cs="100,100"></path><path stroke="#000000" stroke-opacity="0.15" stroke-width="1" fill="none" d="M354.5,288.5 L354.5,288.5 L354.5,0.5" cs="100,100"></path></g><g><path transform="translate(0,288)" stroke="#000000" stroke-opacity="1" stroke-width="1" fill="none" d="M486.5,0.5 L486.5,5.5" cs="100,100"></path><path stroke="#000000" stroke-opacity="0.15" stroke-width="1" fill="none" d="M442.5,288.5 L442.5,288.5 L442.5,0.5" cs="100,100"></path></g><g><path transform="translate(0,288)" stroke="#000000" stroke-opacity="1" stroke-width="1" fill="none" d="M575.5,0.5 L575.5,5.5" cs="100,100"></path><path stroke="#000000" stroke-opacity="0.15" stroke-width="1" fill="none" d="M531.5,288.5 L531.5,288.5 L531.5,0.5" cs="100,100"></path></g><g><path transform="translate(0,288)" stroke="#000000" stroke-opacity="1" stroke-width="1" fill="none" d="M663.5,0.5 L663.5,5.5" cs="100,100"></path><path stroke="#000000" stroke-opacity="0.15" stroke-width="1" fill="none" d="M619.5,288.5 L619.5,288.5 L619.5,0.5" cs="100,100"></path></g><g><path transform="translate(0,288)" stroke="#000000" stroke-opacity="1" stroke-width="1" fill="none" d="M752.5,0.5 L752.5,5.5" cs="100,100"></path><path stroke="#000000" stroke-opacity="0.15" stroke-width="1" fill="none" d="M708.5,288.5 L708.5,288.5 L708.5,0.5" cs="100,100"></path></g><g><path transform="translate(0,288)" stroke="#000000" stroke-opacity="1" stroke-width="1" fill="none" d="M840.5,0.5 L840.5,5.5" cs="100,100"></path><path stroke="#000000" stroke-opacity="0.15" stroke-width="1" fill="none" d="M796.5,288.5 L796.5,288.5 L796.5,0.5" cs="100,100"></path></g><g><path transform="translate(0,288)" stroke="#000000" stroke-opacity="1" stroke-width="1" fill="none" d="M928.5,0.5 L928.5,5.5" cs="100,100"></path><path stroke="#000000" stroke-opacity="0.15" stroke-width="1" fill="none" d="M884.5,288.5 L884.5,288.5 L884.5,0.5" cs="100,100"></path></g><g><path transform="translate(0,288)" stroke="#000000" stroke-opacity="1" stroke-width="1" fill="none" d="M1017.5,0.5 L1017.5,5.5" cs="100,100"></path><path stroke="#000000" stroke-opacity="0.15" stroke-width="1" fill="none" d="M973.5,288.5 L973.5,288.5 L973.5,0.5" cs="100,100"></path></g><g><path transform="translate(0,288)" stroke="#000000" stroke-opacity="1" stroke-width="1" fill="none" d="M1105.5,0.5 L1105.5,5.5" cs="100,100"></path><path stroke="#000000" stroke-opacity="0.15" stroke-width="1" fill="none" d="M1061.5,288.5 L1061.5,288.5 L1061.5,0.5" cs="100,100"></path></g><g><path transform="translate(0,288)" stroke="#000000" stroke-opacity="1" stroke-width="1" fill="none" d="M1194.5,0.5 L1194.5,5.5" cs="100,100"></path><path stroke="#000000" stroke-opacity="0.15" stroke-width="1" fill="none" d="M1150.5,288.5 L1150.5,288.5 L1150.5,0.5" cs="100,100"></path></g><g><path transform="translate(0,288)" stroke="#000000" stroke-opacity="1" stroke-width="1" fill="none" d="M1282.5,0.5 L1282.5,5.5" cs="100,100"></path><path stroke="#000000" stroke-opacity="0.15" stroke-width="1" fill="none" d="M1238.5,288.5 L1238.5,288.5 L1238.5,0.5" cs="100,100"></path></g><g><path transform="translate(0,288)" stroke="#000000" stroke-opacity="1" stroke-width="1" fill="none" d="M1370.5,0.5 L1370.5,5.5" cs="100,100"></path><path stroke="#000000" stroke-opacity="0.15" stroke-width="1" fill="none" d="M1326.5,288.5 L1326.5,288.5 L1326.5,0.5" cs="100,100"></path></g><g><path transform="translate(0,288)" stroke="#000000" stroke-opacity="1" stroke-width="1" fill="none" d="M1459.5,0.5 L1459.5,5.5" cs="100,100"></path><path stroke="#000000" stroke-opacity="0.15" stroke-width="1" fill="none" d="M1415.5,288.5 L1415.5,288.5 L1415.5,0.5" cs="100,100"></path></g><g><path stroke="#000000" stroke-opacity="0.15" stroke-width="1" fill="none" d="M1503.5,288.5 L1503.5,288.5 L1503.5,0.5" cs="100,100"></path></g></g><g visibility="visible" transform="translate(60,20)"><g><path transform="translate(-6,0)" stroke="#000000" stroke-opacity="1" stroke-width="1" fill="none" d="M0.5,288.5 L6.5,288.5" cs="100,100"></path><path stroke="#000000" stroke-opacity="0.15" stroke-width="1" fill="none" d="M0.5,288.5 L0.5,288.5 L1503.5,288.5" cs="100,100"></path></g><g><path transform="translate(-6,0)" stroke="#000000" stroke-opacity="1" stroke-width="1" fill="none" d="M0.5,256.5 L6.5,256.5" cs="100,100"></path><path stroke="#000000" stroke-opacity="0.15" stroke-width="1" fill="none" d="M0.5,256.5 L0.5,256.5 L1503.5,256.5" cs="100,100"></path></g><g><path transform="translate(-6,0)" stroke="#000000" stroke-opacity="1" stroke-width="1" fill="none" d="M0.5,224.5 L6.5,224.5" cs="100,100"></path><path stroke="#000000" stroke-opacity="0.15" stroke-width="1" fill="none" d="M0.5,224.5 L0.5,224.5 L1503.5,224.5" cs="100,100"></path></g><g><path transform="translate(-6,0)" stroke="#000000" stroke-opacity="1" stroke-width="1" fill="none" d="M0.5,192.5 L6.5,192.5" cs="100,100"></path><path stroke="#000000" stroke-opacity="0.15" stroke-width="1" fill="none" d="M0.5,192.5 L0.5,192.5 L1503.5,192.5" cs="100,100"></path></g><g><path transform="translate(-6,0)" stroke="#000000" stroke-opacity="1" stroke-width="1" fill="none" d="M0.5,160.5 L6.5,160.5" cs="100,100"></path><path stroke="#000000" stroke-opacity="0.15" stroke-width="1" fill="none" d="M0.5,160.5 L0.5,160.5 L1503.5,160.5" cs="100,100"></path></g><g><path transform="translate(-6,0)" stroke="#000000" stroke-opacity="1" stroke-width="1" fill="none" d="M0.5,128.5 L6.5,128.5" cs="100,100"></path><path stroke="#000000" stroke-opacity="0.15" stroke-width="1" fill="none" d="M0.5,128.5 L0.5,128.5 L1503.5,128.5" cs="100,100"></path></g><g><path transform="translate(-6,0)" stroke="#000000" stroke-opacity="1" stroke-width="1" fill="none" d="M0.5,96.5 L6.5,96.5" cs="100,100"></path><path stroke="#000000" stroke-opacity="0.15" stroke-width="1" fill="none" d="M0.5,96.5 L0.5,96.5 L1503.5,96.5" cs="100,100"></path></g><g><path transform="translate(-6,0)" stroke="#000000" stroke-opacity="1" stroke-width="1" fill="none" d="M0.5,64.5 L6.5,64.5" cs="100,100"></path><path stroke="#000000" stroke-opacity="0.15" stroke-width="1" fill="none" d="M0.5,64.5 L0.5,64.5 L1503.5,64.5" cs="100,100"></path></g><g><path transform="translate(-6,0)" stroke="#000000" stroke-opacity="1" stroke-width="1" fill="none" d="M0.5,32.5 L6.5,32.5" cs="100,100"></path><path stroke="#000000" stroke-opacity="0.15" stroke-width="1" fill="none" d="M0.5,32.5 L0.5,32.5 L1503.5,32.5" cs="100,100"></path></g><g><path transform="translate(-6,0)" stroke="#000000" stroke-opacity="1" stroke-width="1" fill="none" d="M0.5,0.5 L6.5,0.5" cs="100,100"></path><path stroke="#000000" stroke-opacity="0.15" stroke-width="1" fill="none" d="M0.5,0.5 L0.5,0.5 L1503.5,0.5" cs="100,100"></path></g></g></g><g clip-path="url(#AmChartsEl-3)" transform="translate(60,20)"><g visibility="hidden"></g></g><g></g><g></g><g></g><g><g transform="translate(60,20)"><g><g visibility="visible" transform="translate(9,288)"><path stroke-opacity="0" stroke-width="1" fill-opacity="0.8" stroke="#FF6600" fill="#FF6600" d="M0.5,0.5 L0.5,-257.5 L71.5,-257.5 L71.5,0.5 L0.5,0.5 Z" cs="100,100"></path></g><g visibility="visible" transform="translate(98,288)"><path stroke-opacity="0" stroke-width="1" fill-opacity="0.8" stroke="#FF6600" fill="#FF6600" d="M0.5,0.5 L0.5,-119.5 L71.5,-119.5 L71.5,0.5 L0.5,0.5 Z" cs="100,100"></path></g><g visibility="visible" transform="translate(186,288)"><path stroke-opacity="0" stroke-width="1" fill-opacity="0.8" stroke="#FF6600" fill="#FF6600" d="M0.5,0.5 L0.5,-115.5 L71.5,-115.5 L71.5,0.5 L0.5,0.5 Z" cs="100,100"></path></g><g visibility="visible" transform="translate(274,288)"><path stroke-opacity="0" stroke-width="1" fill-opacity="0.8" stroke="#FF6600" fill="#FF6600" d="M0.5,0.5 L0.5,-84.5 L71.5,-84.5 L71.5,0.5 L0.5,0.5 Z" cs="100,100"></path></g><g visibility="visible" transform="translate(363,288)"><path stroke-opacity="0" stroke-width="1" fill-opacity="0.8" stroke="#FF6600" fill="#FF6600" d="M0.5,0.5 L0.5,-71.5 L71.5,-71.5 L71.5,0.5 L0.5,0.5 Z" cs="100,100"></path></g><g visibility="visible" transform="translate(451,288)"><path stroke-opacity="0" stroke-width="1" fill-opacity="0.8" stroke="#FF6600" fill="#FF6600" d="M0.5,0.5 L0.5,-70.5 L71.5,-70.5 L71.5,0.5 L0.5,0.5 Z" cs="100,100"></path></g><g visibility="visible" transform="translate(540,288)"><path stroke-opacity="0" stroke-width="1" fill-opacity="0.8" stroke="#FF6600" fill="#FF6600" d="M0.5,0.5 L0.5,-62.5 L71.5,-62.5 L71.5,0.5 L0.5,0.5 Z" cs="100,100"></path></g><g visibility="visible" transform="translate(628,288)"><path stroke-opacity="0" stroke-width="1" fill-opacity="0.8" stroke="#FF6600" fill="#FF6600" d="M0.5,0.5 L0.5,-44.5 L71.5,-44.5 L71.5,0.5 L0.5,0.5 Z" cs="100,100"></path></g><g visibility="visible" transform="translate(717,288)"><path stroke-opacity="0" stroke-width="1" fill-opacity="0.8" stroke="#FF6600" fill="#FF6600" d="M0.5,0.5 L0.5,-42.5 L71.5,-42.5 L71.5,0.5 L0.5,0.5 Z" cs="100,100"></path></g><g visibility="visible" transform="translate(805,288)"><path stroke-opacity="0" stroke-width="1" fill-opacity="0.8" stroke="#FF6600" fill="#FF6600" d="M0.5,0.5 L0.5,-36.5 L71.5,-36.5 L71.5,0.5 L0.5,0.5 Z" cs="100,100"></path></g><g visibility="visible" transform="translate(893,288)"><path stroke-opacity="0" stroke-width="1" fill-opacity="0.8" stroke="#FF6600" fill="#FF6600" d="M0.5,0.5 L0.5,-27.5 L71.5,-27.5 L71.5,0.5 L0.5,0.5 Z" cs="100,100"></path></g><g visibility="visible" transform="translate(982,288)"><path stroke-opacity="0" stroke-width="1" fill-opacity="0.8" stroke="#FF6600" fill="#FF6600" d="M0.5,0.5 L0.5,-27.5 L71.5,-27.5 L71.5,0.5 L0.5,0.5 Z" cs="100,100"></path></g><g visibility="visible" transform="translate(1070,288)"><path stroke-opacity="0" stroke-width="1" fill-opacity="0.8" stroke="#FF6600" fill="#FF6600" d="M0.5,0.5 L0.5,-24.5 L71.5,-24.5 L71.5,0.5 L0.5,0.5 Z" cs="100,100"></path></g><g visibility="visible" transform="translate(1159,288)"><path stroke-opacity="0" stroke-width="1" fill-opacity="0.8" stroke="#FF6600" fill="#FF6600" d="M0.5,0.5 L0.5,-24.5 L71.5,-24.5 L71.5,0.5 L0.5,0.5 Z" cs="100,100"></path></g><g visibility="visible" transform="translate(1247,288)"><path stroke-opacity="0" stroke-width="1" fill-opacity="0.8" stroke="#FF6600" fill="#FF6600" d="M0.5,0.5 L0.5,-24.5 L71.5,-24.5 L71.5,0.5 L0.5,0.5 Z" cs="100,100"></path></g><g visibility="visible" transform="translate(1335,288)"><path stroke-opacity="0" stroke-width="1" fill-opacity="0.8" stroke="#FF6600" fill="#FF6600" d="M0.5,0.5 L0.5,-21.5 L71.5,-21.5 L71.5,0.5 L0.5,0.5 Z" cs="100,100"></path></g><g visibility="visible" transform="translate(1424,288)"><path stroke-opacity="0" stroke-width="1" fill-opacity="0.8" stroke="#FF6600" fill="#FF6600" d="M0.5,0.5 L0.5,-20.5 L71.5,-20.5 L71.5,0.5 L0.5,0.5 Z" cs="100,100"></path></g></g></g></g><g></g><g><path transform="translate(60,20)" stroke="#000000" stroke-opacity="0.3" stroke-width="1" fill="none" d="M0.5,288.5 L1503.5,288.5 L1503.5,288.5" cs="100,100"></path><g><path transform="translate(60,308)" stroke="#000000" stroke-opacity="1" stroke-width="1" fill="none" d="M0.5,0.5 L1503.5,0.5" cs="100,100"></path></g><g><path visibility="visible" transform="translate(60,20)" stroke="#000000" stroke-opacity="1" stroke-width="1" fill="none" d="M0.5,0.5 L0.5,288.5" cs="100,100"></path></g></g><g><g clip-path="url(#AmChartsEl-4)" style="pointer-events: none;" transform="translate(60,20)"><path transform="translate(1017,0)" visibility="hidden" stroke="#CC0000" stroke-opacity="0" stroke-width="1" fill="none" d="M0.5,0.5 L0.5,0.5 L0.5,288.5" cs="100,100"></path><path transform="translate(0,49)" visibility="hidden" stroke="#CC0000" stroke-width="1" fill="none" d="M0.5,0.5 L1503.5,0.5 L1503.5,0.5" cs="100,100"></path></g><clipPath id="AmChartsEl-4"><rect stroke-width="0" ry="0" rx="0" height="288" width="1503" y="0" x="0"></rect></clipPath></g><g></g><g><g transform="translate(60,20)"></g></g><g><g></g></g><g><g visibility="visible" transform="translate(60,20)"><text transform="translate(44.205882352941174,309.5) rotate(-90)" text-anchor="middle" opacity="1" font-size="11px" font-family="Verdana" fill="#000000" y="6"><tspan x="0" y="6">USA</tspan></text><text transform="translate(133.20588235294116,314) rotate(-90)" text-anchor="middle" opacity="1" font-size="11px" font-family="Verdana" fill="#000000" y="6"><tspan x="0" y="6">China</tspan></text><text transform="translate(221.20588235294116,314) rotate(-90)" text-anchor="middle" opacity="1" font-size="11px" font-family="Verdana" fill="#000000" y="6"><tspan x="0" y="6">Japan</tspan></text><text transform="translate(309.20588235294116,324) rotate(-90)" text-anchor="middle" opacity="1" font-size="11px" font-family="Verdana" fill="#000000" y="6"><tspan x="0" y="6">Germany</tspan></text><text transform="translate(398.20588235294116,305.5) rotate(-90)" text-anchor="middle" opacity="1" font-size="11px" font-family="Verdana" fill="#000000" y="6"><tspan x="0" y="6">UK</tspan></text><text transform="translate(486.20588235294116,316.5) rotate(-90)" text-anchor="middle" opacity="1" font-size="11px" font-family="Verdana" fill="#000000" y="6"><tspan x="0" y="6">France</tspan></text><text transform="translate(575.2058823529412,312) rotate(-90)" text-anchor="middle" opacity="1" font-size="11px" font-family="Verdana" fill="#000000" y="6"><tspan x="0" y="6">India</tspan></text><text transform="translate(663.2058823529412,313.5) rotate(-90)" text-anchor="middle" opacity="1" font-size="11px" font-family="Verdana" fill="#000000" y="6"><tspan x="0" y="6">Spain</tspan></text><text transform="translate(752.2058823529412,331.5) rotate(-90)" text-anchor="middle" opacity="1" font-size="11px" font-family="Verdana" fill="#000000" y="6"><tspan x="0" y="6">Netherlands</tspan></text><text transform="translate(840.2058823529412,316) rotate(-90)" text-anchor="middle" opacity="1" font-size="11px" font-family="Verdana" fill="#000000" y="6"><tspan x="0" y="6">Russia</tspan></text><text transform="translate(928.2058823529412,333) rotate(-90)" text-anchor="middle" opacity="1" font-size="11px" font-family="Verdana" fill="#000000" y="6"><tspan x="0" y="6">South Korea</tspan></text><text transform="translate(1017.2058823529412,319.5) rotate(-90)" text-anchor="middle" opacity="1" font-size="11px" font-family="Verdana" fill="#000000" y="6"><tspan x="0" y="6">Canada</tspan></text><text transform="translate(1105.2058823529412,313.5) rotate(-90)" text-anchor="middle" opacity="1" font-size="11px" font-family="Verdana" fill="#000000" y="6"><tspan x="0" y="6">Brazil</tspan></text><text transform="translate(1194.2058823529412,310.5) rotate(-90)" text-anchor="middle" opacity="1" font-size="11px" font-family="Verdana" fill="#000000" y="6"><tspan x="0" y="6">Italy</tspan></text><text transform="translate(1282.2058823529412,322.5) rotate(-90)" text-anchor="middle" opacity="1" font-size="11px" font-family="Verdana" fill="#000000" y="6"><tspan x="0" y="6">Australia</tspan></text><text transform="translate(1370.2058823529412,317) rotate(-90)" text-anchor="middle" opacity="1" font-size="11px" font-family="Verdana" fill="#000000" y="6"><tspan x="0" y="6">Taiwan</tspan></text><text transform="translate(1459.2058823529412,316.5) rotate(-90)" text-anchor="middle" opacity="1" font-size="11px" font-family="Verdana" fill="#000000" y="6"><tspan x="0" y="6">Poland</tspan></text></g><g visibility="visible" transform="translate(60,20)"><text transform="translate(-12,286)" text-anchor="end" opacity="1" font-size="11px" font-family="Verdana" fill="#000000" y="6"><tspan x="0" y="6">0</tspan></text><text transform="translate(-12,254)" text-anchor="end" opacity="1" font-size="11px" font-family="Verdana" fill="#000000" y="6"><tspan x="0" y="6">500</tspan></text><text transform="translate(-12,222)" text-anchor="end" opacity="1" font-size="11px" font-family="Verdana" fill="#000000" y="6"><tspan x="0" y="6">1,000</tspan></text><text transform="translate(-12,190)" text-anchor="end" opacity="1" font-size="11px" font-family="Verdana" fill="#000000" y="6"><tspan x="0" y="6">1,500</tspan></text><text transform="translate(-12,158)" text-anchor="end" opacity="1" font-size="11px" font-family="Verdana" fill="#000000" y="6"><tspan x="0" y="6">2,000</tspan></text><text transform="translate(-12,126)" text-anchor="end" opacity="1" font-size="11px" font-family="Verdana" fill="#000000" y="6"><tspan x="0" y="6">2,500</tspan></text><text transform="translate(-12,94)" text-anchor="end" opacity="1" font-size="11px" font-family="Verdana" fill="#000000" y="6"><tspan x="0" y="6">3,000</tspan></text><text transform="translate(-12,62)" text-anchor="end" opacity="1" font-size="11px" font-family="Verdana" fill="#000000" y="6"><tspan x="0" y="6">3,500</tspan></text><text transform="translate(-12,30)" text-anchor="end" opacity="1" font-size="11px" font-family="Verdana" fill="#000000" y="6"><tspan x="0" y="6">4,000</tspan></text><text transform="translate(-12,-2)" text-anchor="end" opacity="1" font-size="11px" font-family="Verdana" fill="#000000" y="6"><tspan x="0" y="6">4,500</tspan></text></g></g><g></g><g transform="translate(60,20)"></g><g></g><g></g><clipPath id="AmChartsEl-3"><rect stroke-width="0" ry="0" rx="0" height="288" width="1503" y="0" x="0"></rect></clipPath></svg><a style="position: absolute; text-decoration: none; color: rgb(0, 0, 0); font-family: Verdana; font-size: 11px; opacity: 0.7; display: block; left: 1435px; top: 25px;" title="JavaScript charts" href="http://www.amcharts.com/javascript-charts/">JS chart by amCharts</a></div></div></div>
    

</body></html>