<?php
session_start();
$date = date("d-m-Y");
$date2 = date("m-Y");
$date3 = date("Y");
if(file_exists($date))
{
        $compteur_f = fopen($date, 'r+');
        $compte = fgets($compteur_f);
}
if(file_exists($date2))
{
        $compteur_f2 = fopen($date2, 'r+');
        $compte2 = fgets($compteur_f2);
}
if(file_exists($date3))
{
        $compteur_f3 = fopen($date3, 'r+');
        $compte3 = fgets($compteur_f3);
}
else {
{
        $compteur_f = fopen($date, 'a+');
        $compte = 0;
}
{
        $compteur_f2 = fopen($date2, 'a+');
        $compte2 = 0;
}
{
        $compteur_f3 = fopen($date3, 'a+');
        $compte3 = 0;
} }
if(!isset($_SESSION['compteur_de_visite']))
{
        $_SESSION['compteur_de_visite'] = 'visite';
        $compte++;
		$compte2++;
		$compte3++;
        fseek($compteur_f, 0);
		fseek($compteur_f2, 0);
		fseek($compteur_f3, 0);
        fputs($compteur_f, $compte);
		fputs($compteur_f2, $compte2);
		fputs($compteur_f3, $compte3);
}
fclose($compteur_f);
fclose($compteur_f2);
fclose($compteur_f3);
header('Content-Type: image/gif');
echo base64_decode('R0lGODlhAQABAIABAP///wAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw==');
?>